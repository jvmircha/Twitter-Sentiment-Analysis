# fake_news_detector
Python program that tests various Natural Language Processing classifiers and determines which ones were most successful.
